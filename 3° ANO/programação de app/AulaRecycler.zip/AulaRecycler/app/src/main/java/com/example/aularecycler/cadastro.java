package com.example.aularecycler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class cadastro extends AppCompatActivity {
    static ArrayList<Produto> listaProdutos;
    EditText novoNome;
    EditText novotipo;
    EditText novopreco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        getSupportActionBar().hide();
        novoNome = findViewById(R.id.Nnome);
        novotipo = findViewById(R.id.Ntipo);
        novopreco = findViewById(R.id.Npreco);
    }

    public void cadastro(View v) {
        try{
            String Nnome = novoNome.getText().toString();
            String Ntipo = novotipo.getText().toString();
            float Npreco = Float.parseFloat(novopreco.getText().toString());
            Produto u = new Produto(Nnome, Ntipo, Npreco);
            listaProdutos.add(u);
            Produto.lista = listaProdutos;
            super.onBackPressed();
        } catch (Exception e) {
            Toast.makeText(this, "Cadastro inválido", Toast.LENGTH_SHORT).show();
        }


    }

}


